#!/usr/bin/env bash
echo " Try 'Image URL
Deploy an image from a Docker registry'
"
apt-get update && apt-get install -y tesseract-ocr libtesseract-dev
